﻿namespace Numbers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double pi = 3.141592653;
            decimal e = 2.7182818284590452m;
            Console.WriteLine("The value of pi: " + pi);
            Console.WriteLine("The value of e: " + e);
        }
    }
}
